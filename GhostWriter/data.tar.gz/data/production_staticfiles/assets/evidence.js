import{j as p,r as c,af as v}from"./vendor.js";import{d as m,g as E}from"./collab_common.js";const g=E(`
    query QUERY_EVIDENCE($where: evidence_bool_exp!) {
        evidence(where:$where) {
            id, caption, description, friendlyName, document
        }
    }
`);function f(){const n=c.useMemo(()=>{var d;const a=parseInt(document.getElementById("graphql-evidence-report-id").innerHTML),i=(d=document.getElementById("graphql-evidence-finding-id"))==null?void 0:d.innerHTML,o=[{report_id:{_eq:a}}];return i!==void 0&&o.push({findingId:{_eq:+i}}),o},[]),{data:e,refetch:t}=v(g,{variables:{where:{_or:n}},pollInterval:1e4}),s=c.useCallback(()=>t().then(()=>{}),[t]),r=e==null?void 0:e.evidence;if(r==null)return null;const l=document.getElementById("graphql-media-url").innerHTML,u=document.getElementById("graphql-evidence-upload-url").innerHTML;return{evidence:r,mediaUrl:l,uploadUrl:u,poll:s}}function q({children:n}){const e=f();return p.jsx(m.Provider,{value:e,children:n})}export{q as P};
